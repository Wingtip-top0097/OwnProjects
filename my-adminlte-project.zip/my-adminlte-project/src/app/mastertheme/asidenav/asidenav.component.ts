import { Component } from '@angular/core';

@Component({
  selector: 'app-asidenav',
  standalone: true,
  imports: [],
  templateUrl: './asidenav.component.html',
  styleUrl: './asidenav.component.scss'
})
export class AsidenavComponent {

}
