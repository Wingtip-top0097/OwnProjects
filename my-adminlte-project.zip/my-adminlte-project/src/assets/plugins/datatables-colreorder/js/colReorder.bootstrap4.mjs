/*! Bootstrap 4 styling wrapper for ColReorder
 * © SpryMedia Ltd - datatables.net/license
 */

import jQuery from 'jquery';
import DataTable from 'datatables.net-bs4';
import ColReorder from 'datatables.net-colreorder';

// Allow reassignment of the $ variable
let $ = jQuery;



export default DataTable;
