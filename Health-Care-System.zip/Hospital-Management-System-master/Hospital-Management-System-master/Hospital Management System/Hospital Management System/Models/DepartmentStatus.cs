﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hospital_Management_System.Models
{
    public class DepartmentStatus
    {
        public string Name { get; set; }
    }
}