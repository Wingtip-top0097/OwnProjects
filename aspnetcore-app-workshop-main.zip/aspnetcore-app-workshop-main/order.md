1. Tools Setup
1. File / New / Backend
1. EF Model
   * Core
   * Session Result
	 * Entity Object
1. Build all API controllers
1. Validation attribute to prevent overlapping sessions in a track
1. Swashbuckle
1. Add Front End, Render Agenda (anonymous)
1. Add front end models entities
1. Add Auth for Admin
   * Every session has an edit link
   * Every track has an add session
1. Attendee - sign in with Twitter and favorite sessions
1. Caching on front end
1. Bundler.Core https://docs.microsoft.com/en-us/aspnet/core/client-side/bundling-and-minification
1. Azure
  1. Publishing
  1. App Insights
  1. Diagnostics

Day 1: Get it functional
Day 2: Make it cool

React front end - show the data

Todo: 
Who covers which part

David: Backend
David: Auth (Twitter is done, will add Google)
Damian: Public and Admin views 
Jon: Seed data, markdown
Jon: SPA with React
