﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConferenceDTO
{
    public class SearchTerm
    {
        public string Query { get; set; }
    }
}