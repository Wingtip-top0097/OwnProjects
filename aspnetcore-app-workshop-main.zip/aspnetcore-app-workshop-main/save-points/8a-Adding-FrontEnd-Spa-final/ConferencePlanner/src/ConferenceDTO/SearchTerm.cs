namespace ConferenceDTO
{
    public class SearchTerm
    {
        public string Query { get; set; }
    }
}